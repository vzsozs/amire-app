// src/context/JobProvider.jsx
import React, { createContext, useState } from 'react';
import { JobContext } from './JobContext'; // Importáljuk a Context-et
import moment from 'moment'; // Szükség van rá a dátumkezeléshez

export const JobProvider = ({ children, initialJobs }) => {
  const [jobs, setJobs] = useState(initialJobs);

  const handleAddJob = (newJobData) => {
    const newJob = {
      id: Date.now(),
      description: 'Nincs leírás megadva.',
      assignedTeam: newJobData.assignedTeam || [],
      color: newJobData.color || '#607D8B',
      schedule: newJobData.schedule || [],
      todoList: newJobData.todoList || [], // Inicializáljuk az üres to-do listát
      ...newJobData,
    };
    setJobs(prevJobs => [...prevJobs, newJob]);
  };

  const handleDeleteJob = (jobIdToDelete) => {
    setJobs(prevJobs => prevJobs.filter(job => job.id !== jobIdToDelete));
  };

  const handleUpdateJob = (updatedJobData) => {
    setJobs(prevJobs => prevJobs.map(job => 
      job.id === updatedJobData.id 
        ? { 
            ...job, 
            ...updatedJobData,
            deadline: moment(updatedJobData.deadline).format('YYYY-MM-DD'),
            color: updatedJobData.color || job.color,
            todoList: updatedJobData.todoList || job.todoList // Todo lista is frissülhet
          } 
        : job
    ));
  };

  const handleAssignTeamMember = (jobId, memberId) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId && !job.assignedTeam.includes(memberId)) {
        return { ...job, assignedTeam: [...job.assignedTeam, memberId] };
      }
      return job;
    }));
  };

  const handleUnassignTeamMember = (jobId, memberId) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId) {
        return { ...job, assignedTeam: (job.assignedTeam || []).filter(id => id !== memberId) };
      }
      return job;
    }));
  };

  const handleToggleJobSchedule = (jobId, dateString) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId) {
        const schedule = job.schedule || [];
        if (schedule.includes(dateString)) {
          return { ...job, schedule: schedule.filter(d => d !== dateString) };
        } else {
          return { ...job, schedule: [...schedule, dateString] };
        }
      }
      return job;
    }));
  };

  const handleAddTodoItem = (jobId, todoText) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId) {
        const newTodoItem = { id: Date.now(), text: todoText, completed: false };
        return { ...job, todoList: [...(job.todoList || []), newTodoItem] };
      }
      return job;
    }));
  };

  const handleToggleTodoItem = (jobId, todoId) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId) {
        const updatedTodoList = (job.todoList || []).map(item =>
          item.id === todoId ? { ...item, completed: !item.completed } : item
        );
        return { ...job, todoList: updatedTodoList };
      }
      return job;
    }));
  };

  const handleDeleteTodoItem = (jobId, todoId) => {
    setJobs(prevJobs => prevJobs.map(job => {
      if (job.id === jobId) {
        return { ...job, todoList: (job.todoList || []).filter(item => item.id !== todoId) };
      }
      return job;
    }));
  };
  
  const value = {
    jobs,
    addJob: handleAddJob,
    deleteJob: handleDeleteJob,
    updateJob: handleUpdateJob,
    assignTeamMember: handleAssignTeamMember,
    unassignTeamMember: handleUnassignTeamMember,
    toggleJobSchedule: handleToggleJobSchedule,
    addTodoItem: handleAddTodoItem,
    toggleTodoItem: handleToggleTodoItem,
    deleteTodoItem: handleDeleteTodoItem,
  };

  return (
    <JobContext.Provider value={value}>
      {children}
    </JobContext.Provider>
  );
};

// Custom hook a JobContext egyszerűbb használatához
export const useJobs = () => {
  const context = useContext(JobContext);
  if (context === undefined) {
    throw new Error('useJobs must be used within a JobProvider');
  }
  return context;
};