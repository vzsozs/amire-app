// src/context/useToast.js
import { useContext } from 'react';
import { ToastContext } from './ToastContext'; // Importáljuk a Context-et

// Custom hook a ToastContext egyszerűbb használatához
// Ezt fogják a komponensek importálni és használni.
export const useToast = () => {
  const context = useContext(ToastContext);
  if (context === undefined) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};