// src/context/TeamContext.jsx
import { createContext } from 'react';

export const TeamContext = createContext();