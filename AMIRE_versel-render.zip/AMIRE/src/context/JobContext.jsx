// src/context/JobContext.jsx
import { createContext } from 'react';

export const JobContext = createContext();